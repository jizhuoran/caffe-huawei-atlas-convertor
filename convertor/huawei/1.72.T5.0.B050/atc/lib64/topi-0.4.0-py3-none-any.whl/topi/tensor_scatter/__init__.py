from __future__ import absolute_import as _abs
from .tensor_scatter import *
