"""
Copyright (R) @huawei.com, all rights reserved
-*- coding:utf-8 -*-
FILE:     __init__.py
DESC:     make a module
CREATED:  2020-4-23 21:12:13
MODIFIED: 2020-4-23 21:12:45
"""
