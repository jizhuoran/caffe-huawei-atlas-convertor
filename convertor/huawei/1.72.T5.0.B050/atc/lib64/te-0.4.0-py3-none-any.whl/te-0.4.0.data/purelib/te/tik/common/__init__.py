"""
Copyright (R) @huawei.com, all rights reserved
-*- coding:utf-8 -*-
FILE:     __init__.py
DESC:     make common a module
CREATED:  2019-08-13 11:33:42
MODIFIED: 2019-08-13 11:33:42
"""
from .util import TikUtil, DTYPE_SIZE
